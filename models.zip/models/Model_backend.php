<?php

class Model_backend extends CI_Model
{
    public function getUser($result)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('email', $result);
        $query = $this->db->get();
        return $query->row_array();
    }
}