<?php 
defined('BASEPATH') or exit('No direct script access allowed');

class Model_auth extends CI_Model
{
    // Auth
    public function getUser($email)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('email', $email);
        $query = $this->db->get();
        return $query->row_array();
    }

    // insert User
    public function insertUser($insert)
    {
        return $this->db->insert('user', $insert);
    }

    public function getUsername($username)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('username', $username);
        $query = $this->db->get();
        return $query->row_array();
    }
}