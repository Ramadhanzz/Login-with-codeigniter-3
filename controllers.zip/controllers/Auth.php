<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_auth');
    }

    public function index()
    {
        $data = [
            'title' => 'Login Example',
            'judul' => 'Example Login',
        ];

        // $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if($this->form_validation->run() == false){
            $this->load->view('layout/header', $data);
            $this->load->view('auth/index', $data);
            $this->load->view('layout/footer', $data);
        } else {
            $this->_Auth();
        }
    }

    private function _Auth()
    {
        $username = $this->input->post('username');
        // $email = $this->input->post('email');
        $password = $this->input->post('password');

        // $user = $this->Model_auth->getUser($email);
        $user = $this->Model_auth->getUsername($username);

        // Jalankan Usernya
        if($user){
            // Cek Passwordnya
            if(password_verify($password, $user['password'])){
                $data = [
                    'email' => $user['email'],
                ];
                $this->session->set_userdata($data);
                redirect('dashboard');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Kata sandi salah!</div>');
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email tidak terdaftar</div>');
            redirect('auth');
        }
    }

    // Registrasi
    public function registrasi()
    {
        $data = [
            'title' => 'Registrasi Example',
            'judul' => 'Example Registrasi',
        ];

        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]', [
            'is_unique' => 'Email sudah terdaftar',
        ]);
        $this->form_validation->set_rules('telepon', 'Telepon', 'required|max_length[13]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');

        if($this->form_validation->run() == false){
            $this->load->view('layout/header', $data);
            $this->load->view('auth/registrasi', $data);
            $this->load->view('layout/footer', $data);
        } else {
            $nama = htmlspecialchars($this->input->post('nama'));
            $email = htmlspecialchars($this->input->post('email'));
            $telepon = $this->input->post('telepon');
            $password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);

            $insert = [
                'nama' => $nama,
                'email' => $email,
                'telepon' => $telepon,
                'password' => $password,
                'created_at' => date("Y-m-d"),
            ];
            
            $result = $this->Model_auth->insertUser($insert);
            if($result == false){
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Akun gagal dibuat</div>');
                redirect('auth/registrasi');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Email berhasil terdaftar</div>');
                redirect('auth');
            }
        }
    }

    // Logout
    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">Anda Telah Logout!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('auth');
    }
}