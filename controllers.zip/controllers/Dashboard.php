<?php 
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_backend');
        if(!$this->session->userdata('email')){
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Halaman membutuhkan otentifikasi!</div>');
            redirect('auth');
        }
    }

    public function index()
    {
        $result = $this->session->userdata('email');
        $data = [
            'title' => 'Dashboard',
            'judul' => 'Dashboard',
            'user' => $this->Model_backend->getUser($result)
        ];

        $this->load->view('admin/index', $data);
    }
} 